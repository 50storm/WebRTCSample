window.__SKYWAY_KEY__ = '<YOUR_KEY_HERE>';
